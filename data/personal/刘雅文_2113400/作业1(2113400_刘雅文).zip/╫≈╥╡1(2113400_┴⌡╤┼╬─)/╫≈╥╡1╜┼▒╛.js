// ==UserScript==
// @name         推荐“南开大学计算机学院”
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  打开哔哩哔哩网页后在搜索框内自动输入“南开大学计算机学院”
// @author       刘雅文
// @match        https://www.bilibili.com/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=bilibili.com
// @grant        none
// ==/UserScript==
(function() {
    'use strict';
    // Get the search input element and check if it exists
    var searchInput = document.querySelector('input.nav-search-input');
    if (searchInput) {
        // Input "南开大学计算机学院" into the search input box
        searchInput.value = '南开大学计算机学院';
        // Trigger the search event
        var event = new Event('input', {
            bubbles: true,
            cancelable: true
        });
        searchInput.dispatchEvent(event);
    }
})();