// ==UserScript==
// @name         学院官网进入后台
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  学院官网进入后台
// @author       sr
// @match        https://cc.nankai.edu.cn/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    location.href=$("#button-login").attr('href')
    console.log("学院官网进入后台")
    $("[class='el-button sso_login_btn el-button--default']").click() //点击sso登录
    $("input[type='text']").val("2111617")/*学号*/
    $("input[type='password']").val("Sr030826")/*密码*/

    // https://webvpn.nankai.edu.cn/*
})();